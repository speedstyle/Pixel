// Define what Discord and credentials mean, and set the new client
// as Discord's bot client
const Discord = require("../node_modules/discord.js");
const credentials = require("../credentials.json");
const client = new Discord.Client();

// Whenever you see "${credentials.}", the line of code is calling to the "credentials.json" file
// Whener you see "$client.", the line of code is calling to the Discord client's code (../node_modules/discord.js)
// Upon successfully connecting, the bot will perform these actions
client.on("ready", () => {
// "${client.guilds.size}" is the amount of servers the bot is in
// "console.log" justs prints the text to the console
  console.log(`I have connected, and am currently in ${client.guilds.size} servers.`);
  // "${credentials.prefix}" asks the credentials.json file what the prefix is
  console.log(`My current prefix is set to ${credentials.prefix}. You can edit this in the "credentials.json" file.`);
  // This changes the bot's "game" (the "playing..." next to it's username in Discord) to the amount of servers it is in
  client.user.setPresence({
    game: {
      name: `on ${client.guilds.size} servers | ${credentials.prefix}help`,
      type: 0
    }
  });
})
// Upon being added to a server, the bot will tell the terminal the server's name, ID and number of members
client.on("guildCreate", guild => {
  console.log(`I just joined a server! It's name is: ${guild.name}, the ID is: ${guild.id} and it has ${guild.memberCount} members (including me)!`);
  // This changes the bot's game to the amount of servers it is in
  client.user.setPresence({
    game: { // "${client.guilds.size} is the amount of guilds that the bot is in"
      name: `on ${client.guilds.size} servers | ${credentials.prefix}help`,
      // "type: 0" is the standard "Online" (the green one), you can look at the discord.js docs to -
      // - view all of the other "types" https://discord.js.org
      type: 0
    }
  });
});
// Upon being kicked or banned from a server, the bot will perform these tasks
client.on("guildDelete", guild => {
  console.log(`I was kicked or banned from ${guild.name}. It's ID is ${guild.id}`);
  client.user.setGame(`on ${client.guilds.size} servers | ${credentials.prefix}help`);
})

// These events will be triggered upon recieving a command
client.on("message", async message => {
  // This tells the bot that if the message's author is a bot, STOP. Otherwise, the bot could trigger -
  // - it's own commands
  if(message.author.bot) return;
  // Without the line below, the bot would check EVERY message. The code below tells the bot to ignore any messages -
  // - that do not start with the prefix
  if(message.content.indexOf(credentials.prefix) !== 0) return;

  // Here we tell the bot what ARGS are (the part after the prefix and command) and what a COMMAND is (the prefix and command name)
  const args = message.content.slice(credentials.prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();

  // Here is our first command; the infamous "ping/pong" command. My prefix is %, so with my bot, if someone said -
  // - "%ping", the bot will return the amount of miliseconds taken to respond
  if(command === "ping") {
    var pingMessage = await message.channel.send("Testing speed, this message will be edited.");
    pingMessage.edit(`Pong! The time taken between me sending the "Testing speed..." message and editing it to this is ${m.createdTimestamp - message.createdTimestamp}ms. Discord's API Latency (that cannot be controlled by my connection speed) is ${Math.round(client.ping)}ms`);
  }
  if(command === "cat") {
    var snekfetch = require('snekfetch');
    var fs = require('fs');
    snekfetch.get('http://lorempixel.com/500/500/cats/')
    .then(r => fs.writeFile('cat.jpg', r.body));
    message.channel.send("Here's a cut, as requested!", {
		file: "cat.jpg"})
  };
});

// This physically logs in to the bot's account (Bot'sUsername#1234)
client.login(credentials.token);
