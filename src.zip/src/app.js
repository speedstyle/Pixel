// Define what Discord and credentials mean, and set the new client
// as Discord's bot client
const Discord = require("../node_modules/discord.js");
const credentials = require("../credentials.json");
const client = new Discord.Client();

// Upon successfully connecting, the bot will say this in the launcher terminal
client.on("ready", () => {
// "${client.guilds.size}" is the amount of servers the bot is in
  console.log(`I have connected, and am currently in ${client.guilds.size} servers.`);
  // This changes the bot's "game" to the amount of servers it is in
  client.user.setPresence({
    game: {
      name: `on ${client.guilds.size} servers`,
      type: 0
    }
  });
})
// Upon being added to a server, the bot will tell the terminal the server's name, ID and number of members
client.on("guildCreate", guild => {
  console.log(`I just joined a server, it's details are: Name: ${guild.name}, ID: ${guild.id} and ${guild.memberCount} members!`);
  // This changes the bot's game to the amount of servers it is in
  client.user.setPresence({
    game: {
      name: `on ${client.guilds.size} servers`,
      type: 0
    }
  });
});

// This physically logs in to the bot's account (Bot'sUsername#1234)
client.login(credentials.token);